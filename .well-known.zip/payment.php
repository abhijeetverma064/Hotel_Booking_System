<html>
    <head>
        <link rel="stylesheet" href="payment.css">
    </head></html>
       <div class="forms">
      <ul class="tab-group">
		<span class="tab active"><a href="#login">free visit</a></span>
		<span class="tab"><a href="#signup">booknow</a></span>
                <ul>
    <form action="#" id="login">
        <div class="f1">
                   <img src="https://www.roomsoom.com/images/others/visit-house.png">
      
       <p>FREE Guided Tour</p>
       <span>with our executive</span>
            <button class="btn-bookpay" >Schedule Free Visit</button>
            </div>
         </form>

</div>
      